/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaparser;

import java.io.File;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
/**
 *
 * @author haffs
 */
public class JavaParser {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
           try {

	SAXParserFactory factory = SAXParserFactory.newInstance();
	SAXParser saxParser = factory.newSAXParser();

	DefaultHandler handler = new DefaultHandler() {

	boolean fname = false;
	boolean lname = false;
	boolean day = false;
        boolean month = false;
        boolean year = false;
	
	public void startElement(String uri, String localName,String qName, 
                Attributes attributes) throws SAXException {

		System.out.println("Start Element :" + qName);

		if (qName.equalsIgnoreCase("firstname")) {
			fname = true;
		}

		if (qName.equalsIgnoreCase("lastname")) {
			lname = true;
		}

		if (qName.equalsIgnoreCase("day")) {
			day = true;
		}
                if (qName.equalsIgnoreCase("month")) {
			month = true;
		}
                if (qName.equalsIgnoreCase("year")) {
			year = true;
		}


	}

	public void endElement(String uri, String localName,
		String qName) throws SAXException {

		System.out.println("End Element :" + qName);

	}

	public void characters(char ch[], int start, int length) throws SAXException {

		if (fname) {
			System.out.println("First Name : " + new String(ch, start, length));
			fname = false;
		}

		if (lname) {
			System.out.println("Last Name : " + new String(ch, start, length));
			lname = false;
		}

		if (day) {
			System.out.println("Day : " + new String(ch, start, length));
			day = false;
		}
                if (month) {
			System.out.println("Month : " + new String(ch, start, length));
			month = false;
		}
                if (year) {
			System.out.println("Year : " + new String(ch, start, length));
			year = false;
		}

	

	}

     };

       saxParser.parse("C:\\Users\\haffs\\OneDrive\\Desktop\\file.xml", handler);
 
     } catch (Exception e) {
       e.printStackTrace();
     }
  
   }

}
